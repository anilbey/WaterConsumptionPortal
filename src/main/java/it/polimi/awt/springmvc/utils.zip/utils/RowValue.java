package it.polimi.awt.springmvc.utils;

/**
 * @author anil
 *
 */
public class RowValue {
	private String v;

	/**
	 * @return
	 */
	public String getV() {
		return v;
	}

	/**
	 * @param v
	 */
	public void setV(String v) {
		this.v = v;
	}

	/**
	 * @param v
	 */
	public RowValue(String v) {
		super();
		this.v = v;
	}



}
